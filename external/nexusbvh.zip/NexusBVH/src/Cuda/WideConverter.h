#pragma once

namespace NXB
{

}